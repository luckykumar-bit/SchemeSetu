# Samarthya AI — Immersive Animation Pack

Original GSAP/Web Audio interaction starter for an immersive Samarthya AI site. Inspired by the ambition of experimental agency websites, not copied from proprietary assets/source.

## Install
npm i gsap

Import `src/animation/engine.js`, add `src/components/immersive.html`, and include the CSS files.

## Includes
- GSAP + ScrollTrigger hero and scroll choreography
- custom inertial cursor
- pointer-reactive atmosphere
- chaos → clarity signature transition
- welfare/credit world transitions
- Web Audio API synthesized UI/transition sounds
- sound toggle + reduced-motion support
- mobile-aware CSS

No proprietary Igloo assets are included.
